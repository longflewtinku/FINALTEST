package eft.com.positivelauncher;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import eft.com.positivelib.PositiveEvent;
import eft.com.positivelib.PositiveLib;
import eft.com.positivelib.PositiveTransEvent;

import static eft.com.positivelib.PositiveLib.TRANSACTION_TYPE_REFUND;
import static eft.com.positivelib.PositiveLib.TRANSACTION_TYPE_SALE;;

/**************************************************************************************************/
/**************************************************************************************************/

/*
   This class sends transaction requests to the positivesvc so that the positive payment app can
   run a transaction.

   NOTES:
   1. The transaction amount is in the smallest currency denomination so for example 100 = $1.00
   2. The transaction currency can not be changed from this app, that must be done by configuration
      of the positive app
   3. The reversal example here is attempting to reverse the last transaction.
      To reverse a specific tranasaction the receipt number of the transaction you wish to reverse can
      be passed in as the last argument to EFTSendRunTrans
   4. R.id.runUtiReversal shows you how to reverse a transaction by passing in the UTI
   5. R.id.queryTransaction show you how to query a previous transaction by the UTI number
   6. See PositiveLaunchReceiver for unpacking of results from both the transaction and the batch upload

*/

/**************************************************************************************************/

/**************************************************************************************************/
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    /* Just a TAG used for debugging */
    private static final String TAG = "MainActivity";
    public static String lastReceivedUTI; /* used to make live easy when testing reversals of the last transaction */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* Map the two buttons to the correct callback */
        Button mClickButton1 = (Button) findViewById(R.id.runTrans);
        mClickButton1.setOnClickListener(this);

        Button mClickButton2 = (Button) findViewById(R.id.runRefund);
        mClickButton2.setOnClickListener(this);

        Button mClickButton4 = (Button) findViewById(R.id.runReverseLast);
        mClickButton4.setOnClickListener(this);

        Button mClickButton10 = (Button) findViewById(R.id.queryTransaction);
        mClickButton10.setOnClickListener(this);

        Button mClickButton11 = (Button) findViewById(R.id.runExit);
        mClickButton11.setOnClickListener(this);

        Button mClickButton12 = (Button) findViewById(R.id.runUtiReversal);
        mClickButton12.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.runTrans: {
                /* Send a request to run a transaction for 100 pence (in the configured app currency */
                Log.i(TAG, "Run Auto Sale");
                //EFTServiceLib.runTrans(this, 100, TRANSACTION_TYPE_SALE, "", "", "");

                /* to run a transaction with a specific user ID or password */
                PositiveLib.runTrans(this, 100, TRANSACTION_TYPE_SALE);
                break;
            }

            case R.id.runRefund: {
                /* Send a request to run a transaction for 100 pence (in the configured app currency */
                Log.i(TAG, "Run Auto Refund");
                PositiveLib.runTrans(this, 100, TRANSACTION_TYPE_REFUND);
                break;
            }

            case R.id.runReverseLast: {
                Log.i(TAG, "Run Auto Reverse Last");
                /* attempt to reverse the last transaction */
                PositiveLib.runReversal(getApplicationContext(), 100, 0);
                break;
            }

            case R.id.runUtiReversal: {
                Log.i(TAG, "Run Uti Reversal");
                /* attempt to reverse the last transaction */
                if (lastReceivedUTI != null && lastReceivedUTI.length() > 0) {
                    PositiveLib.runReversal(getApplicationContext(), 100, lastReceivedUTI, true, true);
                } else {
                    Log.i(TAG, "NO UTI TO Run Reversal on");
                    Toast.makeText(this, "No UTI TO Run Reversal on", Toast.LENGTH_SHORT).show();
                }
                break;
            }

            case R.id.queryTransaction: {
                /* Send a request to reverse a transaction by UTI */
                if (lastReceivedUTI != null && lastReceivedUTI.length() > 0) {
                    Log.i(TAG, "Run Query Trans on:" + lastReceivedUTI);
                    PositiveLib.queryTrans(this, lastReceivedUTI);
                } else {
                    Log.i(TAG, "NO UTI TO Run Query on");
                    Toast.makeText(this, "No UTI TO Run Query on", Toast.LENGTH_SHORT).show();
                }
                break;
            }

            case R.id.runExit: {
                Log.i(TAG, "Exit");
                System.exit(0);
                break;
            }
        }
    }


}

